<template>

  <div class="wrap">
    
    <Spin size="large" fix v-if="spinShow"></Spin>
    <div class="main-header">
        <div class="main-header-nav">
          <Row>
            <Col span="24">
            <ButtonGroup class="fr">
              <Button  
                size="small" 
                @click="goAppManage" 
                type="ghost"
                caseId='apps'>
                <Icon type="navicon-round"></Icon>
                应用管理
              </Button>
              <Button  
                size="small" 
                @click="changeView" 
                type="ghost"
                caseId='apps'>
                <Icon type="android-apps"></Icon>
                全部应用
              </Button>
              <Button size="small"  
                v-for="(pulse,i) in  pulseGraphLlistr" 
                :key="i" 
                type="ghost"
                @click="changeView" 
                :caseId="pulse.id">
                <Icon type="android-share-alt"></Icon>
                {{pulse.name}}
              </Button>
            </ButtonGroup>
            </Col>
          </Row>
        </div>
    </div>
    <div v-if="cutView">
        <section v-for="(menuList,i) in menuList" 
          :key="i" v-bind:class="i%2===0?'bg-white-lighter':'bg-gray-lighter'" >
          <row class="menu-group">
              <row>
                  <h3 style="" class="menu-group-title">{{menuList.text}}</h3>
              </row>

              <row :gutter="16">
                  <Col v-if="item.leaf" v-for="(item,j) in menuList.children" :key="j" span="6">
                    <card-item  v-if="item.leaf"  :appinfo="item" :allTaskCount="allTaskCount"></card-item>
                  </Col>
                  <card-list v-else :menuItem="item" :index='j' :allTaskCount="allTaskCount"></card-list>
              </row>
          </row>
        </section>
    </div>
    <div v-else>
        <pulse-graph :caseId="caseId"></pulse-graph>
    </div>
   
  
  </div>
</template>

<script>
import CardList from "@/components/card/CardList";
import CardItem from "@/components/card/CardItem";
import PulseGraph from "@/views/flow/pulseGraph";
import {  getMenu, getPulsationDiagramCase,getCurrentUserAllTasks} from "@/services/flowService";

export default {
  components: {
    CardList,
    CardItem,
    PulseGraph
  },
  data() {
    return {
      spinShow:true,
      cutView: true,
      menuList: [],
      caseId:'',
      pulseGraphLlistr:[],
      allTaskCount:{}
    };
  },
  created() {

    

    //获取当前用户所有待办任务
    getCurrentUserAllTasks().then(res =>{
     this.allTaskCount = {};

      res.tableContent.map((r)=>{
       this.allTaskCount[r.listId] = r.total;
      });

      //获取菜单信息
      getMenu().then(res => {
        this.menuList = res;
        this.spinShow = false;
      });
    });

    getPulsationDiagramCase().then(res =>{
      this.pulseGraphLlistr = res.tableContent;
    })
  },
  methods: {
    changeView(event) {
      let caseId = event.currentTarget.getAttribute('caseid');
      
      if(caseId === 'apps'){
        this.cutView = true;
      }else{
        this.cutView = false;
        this.caseId = caseId;
      }
    },

    goAppManage(){
      window.open('/Site/index.html#appSetting');
    }
  }
};
</script>

<style lang="less" scoped>
.fr{
  float: right;
}
.menuTitle{
  font-size: 28;
  font-weight: 400;
}

.wrap {
  top: 60px;
  position: relative;
  height: 100%;
  width: 100%;
  background-color: #f0f0f0;
}

.bg-gray-lighter {
  background-color: #f2f2f2;
  padding: 0 10%;
}

.bg-white-lighter {
  background-color: #fff;
  padding: 0 10%;
}

.menu-group {
  margin-bottom: 2rem;
  //   background-color: #fff;
  padding: 5px 10px 20px;
  &-title {
    font-size: 24px;
    font-weight: 400;
    margin-bottom: 10px;
  }
}



.main-header {
   position: fixed;
  z-index: 999;
  top: 0px;
  height: 40px;
  width: 100%;
  padding: 0 10%;
  background-color: #ffffff;
  border-bottom: 1px solid #9e9e9e57;
  z-index: 1000;
  padding: 5px;
  &-nav {
    button {
      cursor: pointer;
      -webkit-box-align: center;
      align-items: center;
      font-size: 14px;
      text-align: center;
      border-radius: 0px;
    }
  }
}
&-container {
  background: #fff;
  margin: 80px auto 15px;
  box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.1);
}
&-content {
  padding: 20px 25px;
  position: relative;
}
</style>

