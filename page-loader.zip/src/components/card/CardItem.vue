<template>

  <div class="card ivu-card ivu-card-bordered">
    <Badge :count="taskCount" 
      class="badge-custom" 
      overflow-count="99">
    </Badge>

    <img :src="appinfo.icon" alt="/resources/images/icon/0_6.png" />
    
    <div  @click="redirectTo(appinfo)">{{appinfo.text}}</div>
    
  </div>

</template>

<script>
export default {
  props: ["text", "icon",'appinfo','allTaskCount'],
  data(){
    return {
      taskCount:0
    }
  },
  created() {
    this.taskCount =  this.allTaskCount[this.appinfo.url.split('/')[1]];
  },
  methods:{
     redirectTo: function(appInfo) {
       var url = appInfo.url;
       if(~appInfo.url.indexOf('app'))
       {
          url = "appReport/" + url;
          
       }

       if(appInfo.url.indexOf('http')<0 && appInfo.url.indexOf('app')<0)
       {
          url = "report/" + url;
       }

      window.top.postMessage(
        {
          type: "redirect",

          url: url
        },

        "*"
      );
    }
  },
};
</script>

<style lang="less" scoped>
.card {
  height: 90px;
  border-radius: 3px;
  padding: 15px 15px;
  margin: 10px 5px;
  img {
    height: 50px;
    width: 50px;
    cursor: pointer;
    position: relative;
  }
  div {
    cursor: pointer;
    font-size: 16px;
    color: #000;
    position: absolute;
    top: 50%;
    left: 80px;
    transform: translateY(-50%);
  }

  .badge-custom {
    top: -10px;
    left: -10px;
    position: absolute;
    transform: translateX(0);
  }
}

.card:hover {
  -webkit-transition: box-shadow 0.3s cubic-bezier(0.55, 0, 0.1, 1) 0s;
  -moz-transition: box-shadow 0.3s cubic-bezier(0.55, 0, 0.1, 1) 0s;
  -o-transition: box-shadow 0.3s cubic-bezier(0.55, 0, 0.1, 1) 0s;
  transition: box-shadow 0.3s cubic-bezier(0.55, 0, 0.1, 1) 0s;
  box-shadow: 0 6px 10px 0 rgba(0, 0, 0, 0.1), 0 2px 2px 0 rgba(0, 0, 0, 0.05);
}

.ivu-card {
  background: #fff;
  font-size: 16px;
  position: relative;
  transition: all 0.2s ease-in-out;
}
.ivu-card-bordered {
  border: 1px solid #dddee1;
  border-color: #e9eaec;
  box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.17);
}
</style>
