<template>
  <row class="menu-field-set" :gutter="16" >
    <label>{{menuItem.text}}</label>

    <Col span="6" v-for="(item,j) in menuItem.children" :key="j">
      <card-item  
        :appinfo="item" 
        :allTaskCount="allTaskCount">
      </card-item>
    </Col>

  </row>
</template>

<script>
import CardItem from "@/components/card/CardItem";

export default {
  props: ["menuItem","allTaskCount"],

  components:{
    CardItem
  },
  created(){
  }

};
</script>

<style lang ='less' scoped>
.menu-field-set {
  margin-left:0px !important;
  margin-right: 0px !important;

  label {
    display: block;
    margin-left: 1%;
    color: gray;
    font-size: 16px;
  }

  .menu-box {
    .menu-item {
      overflow: hidden;
      padding-bottom: 2%;
    }
  }
}
</style>
